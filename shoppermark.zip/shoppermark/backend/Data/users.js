import bcrypt from "bcryptjs"

const users = [
  {
    name: "Admin",
    email: "admin@admin.com",
    password: bcrypt.hashSync('admin123', 10),
    isAdmin: true,
  }
]

export default users